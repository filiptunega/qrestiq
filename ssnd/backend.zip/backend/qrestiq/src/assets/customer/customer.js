// Bázová URL backendu — cez reverse-proxy
const API = '/api';

// hlavné dáta menu (načíta sa z API)
let data = {};

// košík – ukladá položky podľa ID
let cart = {};

// číslo stola, z ktorého ide objednávka
let tableNumber = null;

// zoznam povolených / dostupných stolov
let availableTables = [];

// DOM elementy
const categoriesEl = document.getElementById('categories');
const menuEl = document.getElementById('menu');
const cartEl = document.getElementById('cart');
const cartItemsEl = document.getElementById('cartItems');
const openCartBtn = document.getElementById('openCart');
const submitBtn = document.getElementById('submitBtn');
const noteEl = document.getElementById('note');
const tableInput = document.querySelector('header .input input');
const errorEl = document.querySelector('.input .error');


// ===== NAČÍTANIE DOSTUPNÝCH STOLOV =====
fetch(`${API}/tables`)
    .then(res => res.json())
    .then(tables => {
        // uložíme čísla aktívnych stolov
        availableTables = tables.map(t => t.number);

        // skúsime načítať stôl z URL (?table=3)
        setTableFromQuery();
    })
    .catch(err => console.error('Error loading tables:', err));


// získa parameter z URL (napr. ?table=5)
function getQueryParam(name) {
    const params = new URLSearchParams(window.location.search);
    return params.get(name);
}


// nastaví číslo stola z URL, ak je platné
function setTableFromQuery() {
    const table = parseInt(getQueryParam('table'));

    if (!isNaN(table) && availableTables.includes(table)) {
        tableNumber = table;
        tableInput.value = tableNumber;
        errorEl.style.display = 'none';
        tableInput.style.borderColor = '';
    } else {
        tableNumber = null;
        tableInput.value = '';
        errorEl.style.display = 'block';
        tableInput.style.borderColor = 'red';
    }
}


// kontrola stola pri ručnom písaní
tableInput.addEventListener('input', () => {
    let val = parseInt(tableInput.value);

    if (!isNaN(val) && availableTables.includes(val)) {
        tableNumber = val;
        errorEl.style.display = 'none';
        tableInput.style.borderColor = '';
    } else {
        tableNumber = null;
        errorEl.style.display = 'block';
        tableInput.style.borderColor = 'red';
    }
});


// ===== NAČÍTANIE MENU =====
fetch(`${API}/menu/grouped`)
    .then(res => res.json())
    .then(grouped => {
        data = grouped;

        renderCategories();
        renderAllMenu();
    })
    .catch(err => console.error('Error loading menu:', err));


// vykreslí horné chipy s kategóriami
function renderCategories() {
    categoriesEl.innerHTML = '';

    Object.keys(data).forEach(cat => {
        const c = document.createElement('div');
        c.className = 'chip';
        c.innerText = cat;

        c.onclick = () => scrollToCategory(cat);

        categoriesEl.appendChild(c);
    });
}


// plynulé prescrollovanie na kategóriu
function scrollToCategory(cat) {
    const el = document.getElementById('cat-' + cat);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}


// vykreslí celé menu – všetky kategórie aj položky
function renderAllMenu() {
    menuEl.innerHTML = '';

    Object.keys(data).forEach(cat => {
        const section = document.createElement('div');
        section.className = 'category-section';
        section.id = 'cat-' + cat;
        section.innerHTML = `<h2>${cat}</h2>`;

        data[cat].forEach(item => {
            const div = document.createElement('div');
            div.className = 'item';

            div.innerHTML = `
                <img src="${item.img}" />
                <div class="info">
                    <h3>${item.name}</h3>
                    <p>${item.desc}</p>
                    <div class="price">$${item.price.toFixed(2)}</div>
                </div>
                <button class="add">Add</button>
            `;

            div.querySelector('.add').onclick = () => addToCart(item);

            section.appendChild(div);
        });

        menuEl.appendChild(section);
    });
}


// ===== KOŠÍK =====

// pridanie položky do košíka
function addToCart(item) {
    if (!tableNumber) return;

    cart[item.id] = cart[item.id]
        ? { ...cart[item.id], qty: cart[item.id].qty + 1 }
        : { ...item, qty: 1 };

    updateCart();
}


// aktualizácia košíka + ceny
function updateCart() {
    cartItemsEl.innerHTML = '';
    let total = 0;

    Object.values(cart).forEach(i => {
        total += i.price * i.qty;

        const row = document.createElement('div');
        row.className = 'cart-item';

        row.innerHTML = `
            <div>
                <strong>${i.name}</strong><br>
                <small>$${i.price.toFixed(2)} each</small>
            </div>
            <div class="qty">
                <button>-</button>
                ${i.qty}
                <button>+</button>
            </div>
        `;

        const [minus, plus] = row.querySelectorAll('button');

        minus.onclick = () => {
            i.qty--;
            if (i.qty <= 0) delete cart[i.id];
            updateCart();
        };

        plus.onclick = () => {
            i.qty++;
            updateCart();
        };

        cartItemsEl.appendChild(row);
    });

    const noteText = noteEl.value.trim();

    submitBtn.innerText =
        `Submit Order – $${total.toFixed(2)}` +
        (noteText ? ' (Note added)' : '');

    openCartBtn.style.display =
        Object.keys(cart).length > 0 ? 'block' : 'none';
}


// otvorenie / zatvorenie košíka
function toggleCart(show) {
    cartEl.style.display = show ? 'flex' : 'none';
}

openCartBtn.onclick = () => toggleCart(true);


// ===== ODOSLANIE OBJEDNÁVKY =====
submitBtn.onclick = async () => {
    if (!tableNumber) {
        tableInput.focus();
        return;
    }

    // Zostavenie tela objednávky pre API
    const orderBody = {
        tableNumber: tableNumber,
        note: noteEl.value.trim(),
        items: Object.values(cart).map(i => ({
            menuItemId: i.id,
            quantity: i.qty,
        })),
    };

    submitBtn.disabled = true;
    submitBtn.innerText = 'Sending…';

    try {
        const res = await fetch(`${API}/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(orderBody),
        });

        if (!res.ok) {
            const err = await res.json();
            const msg = err.errors ? err.errors.join('\n') : 'Chyba pri odoslaní objednávky.';
            alert(msg);
            return;
        }

        const order = await res.json();
        console.log('Order created:', order);

        // reset po úspešnom odoslaní
        cart = {};
        noteEl.value = '';
        updateCart();
        toggleCart(false);
        alert(`Objednávka #${order.id} bola úspešne odoslaná!`);

    } catch (err) {
        console.error('Submit error:', err);
        alert('Nepodarilo sa odoslať objednávku. Skúste znova.');
    } finally {
        submitBtn.disabled = false;
    }
};
